  function v = Vec(A)
% function v = Vec(A)
% Stacks the columns of the matrix A.
% GVL4: Section 1.3.7
v = A(:);